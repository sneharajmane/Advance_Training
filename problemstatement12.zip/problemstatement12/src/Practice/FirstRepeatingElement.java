package Practice;

public class FirstRepeatingElement {

}
