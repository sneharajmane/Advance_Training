package practice;

public class BookDetails {

	private String _title;
	private float _price;
	public BookDetails (String title, float price){
		_title = title; 
		_price = price;
	}
	//getters
	public String getTitle() { return _title; } 
	public float getPrice() { return _price; }
	//setters
	public void setTitle(String title) {_title= title; }
	public void setPrice (float price) {_price = price; } 
	public String toString()
	{
	return   _title +" "+ _price;
	}
	
	public static void main(String[] args){	
		BookDetails book1, book2, book3;
		book1 = new BookDetails("programing in java",350.50f );
		book2 = new BookDetails("Let us see",200 );
		book3 = new BookDetails("Mphasis",300 );
		System.out.println(book1);
		System.out.println(book2);
		System.out.println(book3);
	}
}


