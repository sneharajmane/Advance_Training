package Practice;

public class RepeatingDecimal {

}
