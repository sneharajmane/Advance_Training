package Practice;
import java.util.HashMap;
import java.util.Scanner;

public class PhoneBook {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		HashMap<String, String> phoneBook = new HashMap<String, String>();
		Scanner sc = new Scanner(System.in);
		
		while(true)
		{
			System.out.println("-----Phone Book Operations-----");
			System.out.println("1. Add new Phonebook entry");
			System.out.println("2. Search phone number");
			System.out.println("3. Exit");
			
			int choice = sc.nextInt();
			
			if(choice==1)
			{
				System.out.println("Enter Name: ");
				String name = sc.next();
				System.out.println("Enter Phone.no: ");
				String ph = sc.next();
				phoneBook.put(name, ph);
				System.out.println("Added Successfully");
			}
			
			else if(choice==2)
			{
				System.out.println("Enter the name you want to search no. of: ");
				String name = sc.next();
				String phn = phoneBook.get(name);
				if(phn==null)
				{
					System.out.println("This person is not saved in phonebook");
				}
				else
				{
					System.out.println("The phone number of "+name+" is "+phn);
				}
			}
			
			else if(choice==3)
			{
				break;
			}
		}
	}
}



