package com.problemstatement1B;

public class Rectangle {
	float area;
    public Rectangle(float length,float width) {
     area=length*width;
    System.out.println(" ");
    System.out.println("Rectangle Info : ");
    
    System.out.println("Length = " +length);
    System.out.println("Width = " +width);
    System.out.println("area of the rectangle is :"+area);
	}

}
