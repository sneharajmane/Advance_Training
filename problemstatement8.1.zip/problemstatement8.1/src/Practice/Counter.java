package Practice;

public class Counter {

}
