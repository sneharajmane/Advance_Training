package Practice;

public class TrainPlatForm {

}
