package Practice;

public class Mergestatement {

}
