package Practice;

public class Flute extends Instrument {
	void play() {
	System.out.println("Flute is playing tool tool tool tool tool");

}
}
