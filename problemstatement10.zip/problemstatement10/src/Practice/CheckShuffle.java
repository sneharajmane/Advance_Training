package Practice;

public class CheckShuffle {

}
