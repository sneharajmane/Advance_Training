package practice;

public class ArrayManipulation {
	public void sum(int A[])
	{
		int sum = 0;
		for(int i=0;i<=14;i++)
		{
			sum = sum+A[i];
		}
		A[15] = sum;
		System.out.println("Adding Element from 0-14 and storing it in 15");
		printArray(A);
	}
	public void average(int A[])
	{
	
			int sum=0;
		    int avg;
		    for(int i=0;i<=15;i++)
		    {
		    	sum = sum+A[i];
		    	
		    }
		    System.out.println(sum);
		    avg = sum/15;
		    A[16]=avg;
		    System.out.println("Calculating the Average of all number and storing it in 16");
		    printArray(A);
	}
	public void smallestValue(int A[])
	{
		int smallest = A[0];
		for(int i=1;i<16;i++)
		{
			if(A[i] < smallest)
			{
				smallest =A[i];
			}
		}
		A[17] = smallest;
		System.out.println("Finding smallest value from Array and storing it in 17");
		printArray(A);
	}
	public void printArray(int A[])
	{
		for(int i=0;i<A.length; i++)
		{
			System.out.println(A[i]+" ");
		}
		System.out.println();
	}
	public static void main(String[]args){
		ArrayManipulation am = new ArrayManipulation();
			int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
			 			  am.sum(A);
			  am.average(A);
			  am.smallestValue(A);
			 		}

	}