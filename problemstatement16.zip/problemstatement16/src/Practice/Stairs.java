package Practice;

public class Stairs {

}
